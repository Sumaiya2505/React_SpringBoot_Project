package com.project.movieticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieticketApplicationTests {

	@Test
	void contextLoads() {
	}

}
