package com.project.movieticket.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.movieticket.controlller.AdminController;
import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.exception.BookingDetailAlreadyExistException;
import com.project.movieticket.services.AdminService;

@WebMvcTest(AdminController.class)
public class AdminControllerTest 
{
		@Autowired
		private MockMvc mockmvc;
		
		@Autowired
		ObjectMapper mapper;
		
		@MockBean
		private AdminService adminservice;
		
		private Booking_Details bookingdetails;
		
		@BeforeEach
		void setup() 
		{
			bookingdetails = Booking_Details.builder()
					.booking_id(1)
					.user_id("sam")
					.movie_id(1)
					.movie_name("Evil Dead")
					.theatre_name("SVS theatre")
					.tickets_booked(2)
					.cost(400)
					.build();
		}
		
		@Test
		void savebooking() throws Exception 
		{
			Booking_Details book = Booking_Details.builder()
					.user_id("sam")
					.movie_id(1)
					.movie_name("Evil Dead")
					.theatre_name("SVS theatre")
					.tickets_booked(2)
					.cost(400)
					.build();
			
			Mockito.when(adminservice.savebooking(book)).thenReturn(bookingdetails);
			
			 mockmvc.perform(MockMvcRequestBuilders.post("/savebooking")
			.contentType(MediaType.APPLICATION_JSON)
			.content(this.mapper.writeValueAsString(book)))
			 .andExpect(MockMvcResultMatchers.status().isCreated());
		}
}
