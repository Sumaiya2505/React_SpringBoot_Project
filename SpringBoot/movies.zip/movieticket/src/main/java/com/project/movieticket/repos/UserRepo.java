package com.project.movieticket.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.movieticket.entities.User_Details;
@Repository
public interface UserRepo extends JpaRepository<User_Details,String>{

	@Query("select u1 from User_Details u1 where u1.user_email=:mn")
	User_Details findByEmail(@Param("mn")String email);

}
