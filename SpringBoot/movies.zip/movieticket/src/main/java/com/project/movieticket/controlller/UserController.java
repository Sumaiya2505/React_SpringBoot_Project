package com.project.movieticket.controlller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Login_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.entities.User_Details;
import com.project.movieticket.exception.MovieDetailsNotFoundException;
import com.project.movieticket.exception.MovieNameNotFoundException;
import com.project.movieticket.exception.TheatreNameNotFoundException;
import com.project.movieticket.services.UserService;

@RestController
@CrossOrigin(origins="*")
public class UserController 
{
	Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userservice;
	
	@PostMapping("/moviename")
	public Movie_Details savemoviedetails(@RequestBody Movie_Details movie)
	{
		logger.debug("Inside savemovie details method");
		return userservice.savemoviedetails(movie);
	}
	
	@GetMapping("/getmoviename")
	public List<Movie_Details> getmoviename() throws MovieDetailsNotFoundException 
	{
		logger.info("Iam inside getmoviename");
		return userservice.getmoviename();
	}

	@PostMapping("/moviename/{id}")
	public Movie_Details getonlymoviename(@PathVariable("id") int movieid) throws MovieNameNotFoundException
	{
		return userservice.getonlymoviename(movieid);
	}
	
	@GetMapping("/gettheatrename/{id}")
	public String gettheatrename(@PathVariable("id") int movieid) throws TheatreNameNotFoundException 
	{
		return userservice.gettheatrename(movieid);
	}

	
	@DeleteMapping("/cancelticket")
	public String cancelticket(@RequestBody Booking_Details bookingdetails) 
	{
		userservice.cancelticket(bookingdetails);
		return "Ticket Cancelled Successfully";
	}
	
	
	@GetMapping("/viewticketbyid/{id}")
	public Booking_Details viewticketbyid(@PathVariable("id") String userid) 
	{
		return userservice.viewticketbyid(userid);
	}
	
	@PostMapping("/bookticket")
	public String bookticket(@RequestBody Booking_Details bookingdetails) 
	{
		return userservice.bookticket(bookingdetails);
	}
	
	@PostMapping("/register")
	public User_Details register(@RequestBody User_Details user) 
	{
		return userservice.register(user);
	}
	
	@PostMapping("/login")
	public Login_Details login(@RequestBody Login_Details logindetails) 
	{
		return userservice.login(logindetails);
	}
	
	@GetMapping("/viewlogin")
	public List<Login_Details> viewlogin() 
	{
		return userservice.viewlogin();
	}
	
	@PostMapping("/getregister")
	public User_Details getregister(@RequestBody Login_Details logindetails)
	{
		return userservice.getregister(logindetails);
	}
	
	@PostMapping("/viewbookingsbyid")
	public List<Booking_Details> viewbookingsbyid(@RequestBody User_Details userdetail)
	{
		return userservice.viewbookingsbyid(userdetail);
	}
	
}
