package com.project.movieticket.repos;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.movieticket.entities.Movie_Details;

@Repository
public interface MovieRepo extends JpaRepository<Movie_Details,Integer> 
{

	@Query(" select m1.movie_name from Movie_Details m1  WHERE m1.movie_id = :m ")
	public String getname(@Param("m") int movie_id);
	
	@Query("select m1.theatre_name from Movie_Details m1 where m1.movie_id = :mo")
	public String gettheatrename(@Param("mo") int movie_id);

	@Query("select m1.available_tickets from Movie_Details m1 where m1.movie_name = :mon")
	public int findAvailableTickets(@Param("mon") String moviename);

	@Query("select m1 from Movie_Details m1 where m1.movie_name = :mn")
	public Movie_Details findByMovie_Name(@Param("mn")String moviename);

	
	

}
