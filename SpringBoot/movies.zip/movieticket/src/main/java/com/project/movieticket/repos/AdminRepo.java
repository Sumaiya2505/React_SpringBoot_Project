package com.project.movieticket.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.movieticket.entities.Admin_Details;

public interface AdminRepo extends JpaRepository<Admin_Details,String>{

}
