package com.project.movieticket.entities;

import java.time.*;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Builder;


@Entity
@Builder
public class Movie_Details
{
		@Id
		
		private int movie_id;
		
		private String movie_name;
		
		private String theatre_name;
		
		private int available_tickets;

		public int getMovie_id() {
			return movie_id;
		}

		public void setMovie_id(int movie_id) {
			this.movie_id = movie_id;
		}

		public String getMovie_name() {
			return movie_name;
		}

		public void setMovie_name(String movie_name) {
			this.movie_name = movie_name;
		}

		public String getTheatre_name() {
			return theatre_name;
		}

		public void setTheatre_name(String theatre_name) {
			this.theatre_name = theatre_name;
		}

		public int getAvailable_tickets() {
			return available_tickets;
		}

		public void setAvailable_tickets(int available_tickets) {
			this.available_tickets = available_tickets;
		}

		public Movie_Details(int movie_id, String movie_name, String theatre_name, int available_tickets) {
			super();
			this.movie_id = movie_id;
			this.movie_name = movie_name;
			this.theatre_name = theatre_name;
			this.available_tickets = available_tickets;
		}

		public Movie_Details() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		
}
