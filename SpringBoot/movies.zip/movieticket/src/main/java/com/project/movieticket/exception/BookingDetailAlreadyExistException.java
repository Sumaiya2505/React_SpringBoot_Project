package com.project.movieticket.exception;

public class BookingDetailAlreadyExistException extends Exception
{
		private String message;

		public BookingDetailAlreadyExistException() {
			super();
			// TODO Auto-generated constructor stub
		}

		public BookingDetailAlreadyExistException(String message) {
			super();
			this.message = message;
		}
		
}
