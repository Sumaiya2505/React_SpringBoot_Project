package com.project.movieticket.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.movieticket.entities.Booking_Details;

public interface BookingRepo extends JpaRepository<Booking_Details,String>
{

	
	@Query("select b1.tickets_booked from Booking_Details b1 where b1.movie_name = :movie")
	int getticketsbookedbymoviename(@Param("movie")String moviename);

	@Query("select b1 from Booking_Details b1 where b1.user_id = :mm")
	Booking_Details findByMail(@Param("mm")String email);

	 

}
