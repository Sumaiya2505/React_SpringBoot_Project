package com.project.movieticket.services;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.exception.BookingDetailAlreadyExistException;
import com.project.movieticket.repos.BookingRepo;
import com.project.movieticket.repos.MovieRepo;

@Service
public class AdminServiceImpl implements AdminService
{

	@Autowired
    private BookingRepo bookingrepo;
	
	@Autowired
	private MovieRepo movierepo;
	
	@Override
	public Booking_Details savebooking(Booking_Details bookingdetails) throws BookingDetailAlreadyExistException
	{
		if(!bookingrepo.existsById(bookingdetails.getUser_id())) 
		{
			return bookingrepo.save(bookingdetails);
		}
		else 
		{
			throw new BookingDetailAlreadyExistException();
		}
		
	}

	@Override
	public List<Booking_Details> viewbooking() 
	{
		return bookingrepo.findAll();
	}

	@Override
	public int getavailableticketsbymoviename(String moviename) {
		// TODO Auto-generated method stub
		return movierepo.findAvailableTickets(moviename);
	}

	@Override
	public int getticketsbookedbymoviename(String moviename) {
		// TODO Auto-generated method stub
		return bookingrepo.getticketsbookedbymoviename(moviename);
	}

	@Override
	public Movie_Details updatemoviename(Movie_Details movie) {
		// TODO Auto-generated method stub
		Movie_Details movie1 = movierepo.findById(movie.getMovie_id()).get();
		if(Objects.nonNull(movie.getMovie_name()) && !"".equalsIgnoreCase(movie.getMovie_name()) && Objects.nonNull(movie.getTheatre_name()) && !"".equalsIgnoreCase(movie.getTheatre_name()) && movie.getAvailable_tickets()>=0) 
		{
			movie1.setMovie_name(movie.getMovie_name());
			movie1.setTheatre_name(movie.getTheatre_name());
			movie1.setAvailable_tickets(movie.getAvailable_tickets());
			
		}
		return movierepo.save(movie1);
	}

	@Override
	public Movie_Details updatetheatrename(int movieid, Movie_Details movie) {
		// TODO Auto-generated method stub
		Movie_Details movie2 = movierepo.findById(movieid).get();
		if(Objects.nonNull(movie.getTheatre_name()) && !"".equalsIgnoreCase(movie.getTheatre_name())) 
		{
			movie2.setTheatre_name(movie.getTheatre_name());
		}
		return movierepo.save(movie2);
	}

	@Override
	public String deletemovie(int movieId) 
	{
		movierepo.deleteById(movieId);
		return "Movie Details deleted successfully !!!";
	}

	
}
