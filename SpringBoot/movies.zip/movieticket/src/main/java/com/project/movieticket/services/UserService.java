package com.project.movieticket.services;

import java.util.List;

import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Login_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.entities.User_Details;
import com.project.movieticket.exception.MovieDetailsNotFoundException;
import com.project.movieticket.exception.MovieNameNotFoundException;
import com.project.movieticket.exception.TheatreNameNotFoundException;


public interface UserService {

 public	Movie_Details savemoviedetails(Movie_Details movie);

 public List<Movie_Details> getmoviename() throws MovieDetailsNotFoundException;

 public Movie_Details getonlymoviename(int movieid) throws MovieNameNotFoundException;

 public String gettheatrename(int movieid) throws TheatreNameNotFoundException;

 public void cancelticket(Booking_Details bookingdetails);

 public Booking_Details viewticketbyid(String userid);

 public String bookticket(Booking_Details bookingdetails);

public User_Details register(User_Details user);

public Login_Details login(Login_Details logindetails);

public List<Login_Details> viewlogin();

public User_Details getregister(Login_Details logindetails);

public List<Booking_Details> viewbookingsbyid(User_Details userdetail);


 
 

	
	

}
