package com.project.movieticket.controlller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.exception.BookingDetailAlreadyExistException;
import com.project.movieticket.services.AdminService;

@RestController
@CrossOrigin(origins="*")
public class AdminController 
{
	@Autowired
   private AdminService adminservice;
	
	@PostMapping("/savebooking")
	public  Booking_Details savebooking(@RequestBody Booking_Details bookingdetails) throws BookingDetailAlreadyExistException 
	{
		return adminservice.savebooking(bookingdetails);
	}
	
	@DeleteMapping("/deletemovie/{id}")
	public String deletemovie(@PathVariable("id") int movieId) 
	{
		return adminservice.deletemovie(movieId);
	}
	
	@GetMapping("/viewbookings")
	public List<Booking_Details> viewbooking() 
	{
		return adminservice.viewbooking();
	}

	@GetMapping("/getavailableticketsbymoviename/{moviename}")
	public int getavailableticketsbymovienname(@PathVariable("moviename") String moviename) 
	{
		return adminservice.getavailableticketsbymoviename(moviename);
	}
	
	
	@GetMapping("/ticketsbookedbymoviename/{moviename}")
	public int getticketsbookedbymoviename(@PathVariable("moviename") String moviename) 
	{
		return adminservice.getticketsbookedbymoviename(moviename);
	}
	
	@PutMapping("/updatemoviename")
	public Movie_Details updatemoviename(@RequestBody Movie_Details movie) 
	{
		return adminservice.updatemoviename(movie);
	}
	
	@PutMapping("/updatetheatrenmae/{id}")
	public Movie_Details updatetheatrename(@PathVariable("id") int movieid,@RequestBody Movie_Details movie) 
	{
		return adminservice.updatetheatrename(movieid,movie);
	}
}
