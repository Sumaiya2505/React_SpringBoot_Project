package com.project.movieticket.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;


@Entity
public class Booking_Details 
{
	@Id
	private String booking_id;
	private String user_name;
	private String user_id;
	private String movie_name;
	private String date;
	private String show_time;
	private String theatre_name;
	private int tickets_booked;
	private int cost;
	public String getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(String booking_id) {
		this.booking_id = booking_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getShow_time() {
		return show_time;
	}
	public void setShow_time(String show_time) {
		this.show_time = show_time;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public int getTickets_booked() {
		return tickets_booked;
	}
	public void setTickets_booked(int tickets_booked) {
		this.tickets_booked = tickets_booked;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Booking_Details [booking_id=" + booking_id + ", user_name=" + user_name + ", user_id=" + user_id
				+ ", movie_name=" + movie_name + ", date=" + date + ", show_time=" + show_time + ", theatre_name="
				+ theatre_name + ", tickets_booked=" + tickets_booked + ", cost=" + cost + "]";
	}
	public Booking_Details(String booking_id, String user_name, String user_id, String movie_name, String date,
			String show_time, String theatre_name, int tickets_booked, int cost) {
		super();
		this.booking_id = booking_id;
		this.user_name = user_name;
		this.user_id = user_id;
		this.movie_name = movie_name;
		this.date = date;
		this.show_time = show_time;
		this.theatre_name = theatre_name;
		this.tickets_booked = tickets_booked;
		this.cost = cost;
	}
	public Booking_Details() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
