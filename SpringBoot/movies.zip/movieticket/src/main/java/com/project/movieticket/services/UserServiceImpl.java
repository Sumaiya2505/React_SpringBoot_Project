package com.project.movieticket.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Login_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.entities.User_Details;
import com.project.movieticket.exception.MovieDetailsNotFoundException;
import com.project.movieticket.exception.MovieNameNotFoundException;
import com.project.movieticket.repos.BookingRepo;
import com.project.movieticket.repos.LoginRepo;
import com.project.movieticket.repos.MovieRepo;
import com.project.movieticket.repos.UserRepo;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private MovieRepo movierepo;
	
	@Autowired
	private BookingRepo bookingrepo;
	
	@Autowired
	private UserRepo userrepo;
	
	@Autowired
	private LoginRepo loginrepo;

	@Override
	public Movie_Details savemoviedetails(Movie_Details movie) {
		// TODO Auto-generated method stub
		return movierepo.save(movie);
	}

	@Override
	public List<Movie_Details> getmoviename() throws MovieDetailsNotFoundException 
	{
		return movierepo.findAll();
	}

	@Override
	public Movie_Details getonlymoviename(int movieid) throws MovieNameNotFoundException 
	{
		if(movierepo.existsById(movieid)) 
		{
			return movierepo.findById(movieid).get();
		}
		else 
		{
			throw new MovieNameNotFoundException();
		}
		
	}

	@Override
	public String gettheatrename(int movieid) {
		// TODO Auto-generated method stub
		return movierepo.gettheatrename(movieid);
	}

	@Override
	public void cancelticket(Booking_Details bookingdetails) 
	{
		// TODO Auto-generated method stub
		 bookingrepo.delete(bookingdetails);
	}

	@Override
	public Booking_Details viewticketbyid(String userid) 
	{
		// TODO Auto-generated method stub
		return bookingrepo.findById(userid).get();
	}

	@Override
	public String bookticket(Booking_Details bookingdetails) 
	{

		Movie_Details movie = movierepo.findByMovie_Name(bookingdetails.getMovie_name());
		int ticketsbooked =bookingdetails.getTickets_booked();
		int ticketsavailable = movie.getAvailable_tickets();
		if(ticketsbooked < ticketsavailable || ticketsbooked==0) 
		{
			ticketsavailable = ticketsavailable - ticketsbooked;
			movie.setAvailable_tickets(ticketsavailable);
			bookingrepo.save(bookingdetails);
			return "Ticket Booked Successfully";
		}
		return "No Ticket is not available for the movie you are trying to book";
		
	}

	@Override
	public User_Details register(User_Details user) 
	{
		return userrepo.save(user);
	}

	@Override
	public Login_Details login(Login_Details logindetails) 
	{
		return loginrepo.save(logindetails);
	}

	@Override
	public List<Login_Details> viewlogin() {
		// TODO Auto-generated method stub
		return loginrepo.findAll();
	}

	@Override
	public User_Details getregister(Login_Details logindetails) {
		// TODO Auto-generated method stub
		String email=logindetails.getUser_email();
		User_Details user=userrepo.findByEmail(email);
		return user;
	}

	@Override
	public List<Booking_Details> viewbookingsbyid(User_Details userdetail) {
		List<Booking_Details> book = new ArrayList<>();
		List<Booking_Details> booklog = bookingrepo.findAll();
		for(Booking_Details books:booklog) 
		{
			if(books.getUser_id().equals(userdetail.getUser_email()))
			{
				book.add(books);
			}
		}
		return book;
	}

	

	

	

	

	

	
	
	
		
	
	
}
