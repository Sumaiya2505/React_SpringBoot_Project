package com.project.movieticket.exception;

public class MovieNameNotFoundException extends Exception
{
	private String message;

	public MovieNameNotFoundException(String message) {
		super();
		this.message = message;
	}

	public MovieNameNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
