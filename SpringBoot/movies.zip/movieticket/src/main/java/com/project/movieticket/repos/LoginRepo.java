package com.project.movieticket.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.movieticket.entities.Login_Details;

@Repository
public interface LoginRepo extends JpaRepository<Login_Details,String>{

}
