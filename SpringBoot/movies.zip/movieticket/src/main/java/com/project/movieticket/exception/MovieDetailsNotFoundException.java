package com.project.movieticket.exception;


public class MovieDetailsNotFoundException extends Exception
{
	private String message;

	public MovieDetailsNotFoundException() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public MovieDetailsNotFoundException(String message) 
	{
		super(message);
		this.message=message;
	}

	
	
	
	
	
}
