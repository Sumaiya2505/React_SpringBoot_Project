package com.project.movieticket.services;

import java.util.List;

import com.project.movieticket.entities.Booking_Details;
import com.project.movieticket.entities.Movie_Details;
import com.project.movieticket.exception.BookingDetailAlreadyExistException;

public interface AdminService {

	public Booking_Details savebooking(Booking_Details bookingdetails) throws BookingDetailAlreadyExistException;

	public List<Booking_Details> viewbooking();

	public int getavailableticketsbymoviename(String moviename);

	public int getticketsbookedbymoviename(String moviename);

	public Movie_Details updatemoviename(Movie_Details movie);

	public Movie_Details updatetheatrename(int movieid, Movie_Details movie);

	public String deletemovie(int movieId);

}
