package com.project.movieticket.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler 
{
	@ExceptionHandler(value=MovieDetailsNotFoundException.class)
	public ResponseEntity moviedetailsnotfoundexception(MovieDetailsNotFoundException ex) 
	{
		return new ResponseEntity("Movie Details Not Found",HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=MovieNameNotFoundException.class)
	public ResponseEntity movienamenotfoundexception(MovieNameNotFoundException ex) 
	{
		return new ResponseEntity("Movie Name Not Found",HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=TheatreNameNotFoundException.class)
	public ResponseEntity theatrenamenotfoundexception(TheatreNameNotFoundException exc) 
	{
		return new ResponseEntity("Theatre Name Not Found",HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value=BookingDetailAlreadyExistException.class)
	public ResponseEntity bookingdetailalreadyexistexception(BookingDetailAlreadyExistException me) 
	{
		return new ResponseEntity("The following details already exist",HttpStatus.CONFLICT);
	}
}
