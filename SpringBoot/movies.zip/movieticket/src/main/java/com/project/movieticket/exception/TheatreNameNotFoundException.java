package com.project.movieticket.exception;

public class TheatreNameNotFoundException extends Exception 
{
		private String message;

		public TheatreNameNotFoundException() {
			super();
			// TODO Auto-generated constructor stub
		}

		public TheatreNameNotFoundException(String message) {
			super();
			this.message = message;
		}
		
}
